/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.geminispro.miweb.DAO;

import com.mycompany.geminispro.miweb.conexion.conexionDB;
import com.mycompany.geminispro.miweb.modelo.cliente;
import java.sql.*;
import java.util.*;
/**
 *
 * @author marko
 */
public class clienteDAO {
    private Connection conexion=null;
    private PreparedStatement prest=null;
    private ResultSet res=null;
    
    public ArrayList<cliente> mostrar(){
        ArrayList<cliente> clientelista=new ArrayList<>();
        
        try{
            conexion=conexionDB.getConnection();
            prest=conexion.prepareStatement("select * from cliente");
            res=prest.executeQuery();
            
            while(res.next()){
                cliente cl=new cliente();
                cl.setId_cliente(res.getInt("id_cliente"));
                cl.setIdentificacion(res.getString("identificacion"));
                cl.setNombres(res.getString("nombres"));
                cl.setCorreo(res.getString("correo"));
                cl.setDireccion(res.getString("direccion"));
                cl.setCiudad(res.getString("ciudad"));
                cl.setTelefono(res.getString("telefono"));
                clientelista.add(cl);
            }
        }
        catch(Exception e){
            e.printStackTrace();
            
        }
        finally{
            try{
                if (conexion!=null){
                }
                if (prest!=null){
                    prest.close();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }          
        }
        return clientelista;
    }
    
}
