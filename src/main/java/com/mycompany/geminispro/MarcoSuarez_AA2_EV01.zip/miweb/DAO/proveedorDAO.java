/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.geminispro.miweb.DAO;

import com.mycompany.geminispro.miweb.conexion.conexionDB;
import com.mycompany.geminispro.miweb.modelo.proveedor;
import java.sql.*;
import java.util.*;
/**
 *
 * @author marko
 */
public class proveedorDAO {
    
    private Connection conexion=null;
    private PreparedStatement prest=null;
    private ResultSet res=null;
    
    public ArrayList<proveedor> mostrar(){
        ArrayList<proveedor> proveedorlista=new ArrayList<>();
        
        try{
            conexion=conexionDB.getConnection();
            prest=conexion.prepareStatement("select * from proveedor");
            res=prest.executeQuery();
            
            while(res.next()){
                proveedor pv=new proveedor();
                pv.setId_proveedor(res.getInt("id_proveedor"));
                pv.setIdentificacion(res.getString("identificacion"));
                pv.setNombre_empresa(res.getString("nombre_empresa"));
                pv.setCorreo(res.getString("correo"));
                pv.setDireccion(res.getString("direccion"));
                pv.setCiudad(res.getString("ciudad"));
                pv.setTelefono(res.getString("telefono"));
                proveedorlista.add(pv);
            }
        }
        catch(Exception e){
            e.printStackTrace();
            
        }
        finally{
            try{
                if (conexion!=null){
                }
                if (prest!=null){
                    prest.close();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }          
        }
        return proveedorlista;
    }
    
}
